﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10069317_Paballo_Ranoto_
{
    public class Logic
    {
        //Declarations
        private Ingredients[] food;
        private Ingredients[] steps;
        int numberOfIngredients;
        int numberOfSteps;
        int i;
        

        public void Add()
        {
            //Ask user to enter number of ingredients
            Console.WriteLine("Welcome to ingredient Note");
            Console.WriteLine("===========================");
            Console.Write("Enter the number of ingredients: ");
            numberOfIngredients = Convert.ToInt32(Console.ReadLine());

            //Call class ingredients
            food = new Ingredients[numberOfIngredients];
            

            //A for loop to store the user input in a class 
            for (int i = 0; i < numberOfIngredients; i++)
            {

                food[i] = new Ingredients();

                Console.WriteLine("---------------------------------------------");
                Console.Write($"Name of ingredient {i+1}: ");
                food[i].Name = Console.ReadLine();

                Console.Write($"What is the quantity of the ingredient {i+1}: ");
                food[i].Quantity = Convert.ToInt32(Console.ReadLine());

                Console.Write($"What is the unit of measurement {i+1}: ");
                food[i].Unit = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("---------------------------------------------");
            }

            Console.WriteLine("How many steps for the ingredients");
            numberOfSteps = Convert.ToInt32(Console.ReadLine());

            steps = new Ingredients[numberOfSteps];

            for (int i = 0; i < numberOfSteps; i++)
            {

                steps[i] = new Ingredients();

                Console.Write($"Step {i +1}: ");
                steps[i].Steps = Console.ReadLine();
            }
        }

        public void show()
        {
            for (int i = 0; i < numberOfIngredients; i++)
            {
                Console.WriteLine($"Ingredient");
                Console.WriteLine("============================================");
                Console.WriteLine($"Name of Ingredient {food[i].Name}");
                Console.WriteLine($"Quantity {food[i].Quantity}");
                Console.WriteLine($"Unit {food[i].Unit}");
                //Console.WriteLine($"Steps {steps[i].Steps}");
                Console.WriteLine("============================================");
            }

            for(int i = 0; i < numberOfSteps; i++)
            {
                Console.WriteLine($"Step {steps[i].Steps}");
            }
            

        }

        public void Scale()
        {
             //Declaration
            double factor;

            //Ask user of the factor they want to enter
            Console.WriteLine("What factor do u want to scale the Quantity of the Ingrdients");
            Console.WriteLine("[0.5 (Half)] or [2.0 (Double)] or [3.0 (trible)] ");

            //User Input
            factor = Convert.ToDouble(Console.ReadLine());

            if (factor == 0.5 || factor == 2 || factor == 3)
            {
                for (int i = 0; i < numberOfIngredients; i++)
                {
                    //factor the quantity by 0.5 multiply by 0.5
                    food[i].Quantity *= factor;
                }
            }
            else
            {
                Console.WriteLine("Invalid amount");
            }
        }

        public void Reset()
        {
            food[i].Quantity = food[i].Quantity;
        }

        public void Clear()
        {
            food[i].Name = null;
            food[i].Quantity = 0;
            food[i].Unit = 0;
            steps[i].Steps = null;
        }
    }
}
