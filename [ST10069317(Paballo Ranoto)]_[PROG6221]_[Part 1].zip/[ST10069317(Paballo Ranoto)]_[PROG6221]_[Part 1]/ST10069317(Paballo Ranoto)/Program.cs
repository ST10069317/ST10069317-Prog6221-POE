﻿using ST10069317_Paballo_Ranoto_;
using System;
using System.ComponentModel;
using System.Linq.Expressions;
using static System.Formats.Asn1.AsnWriter;

public class Program
{
    public static void Main(string[] args)
    {

        Logic logic = new Logic();

        while (true)
        {
            Console.WriteLine("Welsome to ingredients Note");
            Console.WriteLine("====================================");
            Console.WriteLine("1 - Add");
            Console.WriteLine("2 - Scale");
            Console.WriteLine("3 - Reset");
            Console.WriteLine("4 - Clear");
            Console.WriteLine("5 - Show");
            Console.WriteLine("6 - Exit");
            Console.WriteLine("=====================================");
            Console.Write("Choose an option: ");
            int respond = Convert.ToInt32(Console.ReadLine());

            switch (respond)
            {
                case 1:
                    logic.Add();
                    break;

                case 2:
                    logic.Scale();
                    break;

                case 3:
                    logic.Reset();
                    break;

                case 4:
                    logic.Clear();
                    break;

                case 5:
                    logic.show();
                    break;

                case 6:
                    Console.WriteLine("Good bye");
                    Environment.Exit(1);
                    break;

                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
        }
    }
}